from PIL import Image, ImageOps
import os

# Define the image paths and their target sizes
images = {
    "ecommerce.jpg": (1920, 1080),  # Hero image
    "headphones.jpg": (400, 400),   # Product images
    "shoe.jpg": (400, 400),
    "handwatch.jpg": (400, 400),
    "electronics.jpg": (800, 300),  # Category images
    "fashion.jpg": (800, 300),
    "home and living.jpg": (800, 300)
}

# Directory where original images are stored
input_dir = "."
# Directory where resized images will be saved
output_dir = "./resized_images"

# Create the output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Function to resize images while maintaining aspect ratio and adding padding
def resize_image(image_path, target_size, output_path):
    with Image.open(image_path) as img:
        img.thumbnail(target_size, Image.ANTIALIAS)
        # Create a new image with a white background
        new_img = Image.new("RGB", target_size, (255, 255, 255))
        # Calculate the position to paste the resized image onto the new image
        paste_position = ((target_size[0] - img.size[0]) // 2, (target_size[1] - img.size[1]) // 2)
        new_img.paste(img, paste_position)
        new_img.save(output_path)
        print(f"Resized {image_path} to fit within {target_size} and saved to {output_path}")

# Resize each image
for image_name, target_size in images.items():
    input_path = os.path.join(input_dir, image_name)
    output_path = os.path.join(output_dir, image_name)
    if os.path.exists(input_path):
        resize_image(input_path, target_size, output_path)
    else:
        print(f"Image {input_path} not found.")